# Template KAK & Laporan Kegiatan

Status: Draft KAK

<aside>
ℹ️

Bagian A (KAK) disusun **Agen Perancang Kegiatan** dan disetujui penyelenggara sebelum kegiatan dimulai. Bagian B (Laporan) disusun **Agen Pelaporan** dari database Peserta dan Absensi & Log, lalu ditandatangani penyelenggara. Laporan PUB maks. 14 hari kerja setelah kegiatan berakhir.

</aside>

# A. Kerangka Acuan Kerja (KAK)

## 1. Latar Belakang

## 2. Dasar Hukum

- SKKNI / SKK Khusus terkait jabatan sasaran:
- Permen PUPR No. 12 Tahun 2021 tentang Pelaksanaan PKB (untuk kegiatan PKB)
- Permen PUPR No. 7 Tahun 2024 tentang Pengembangan Usaha Berkelanjutan (untuk kegiatan PUB)

## 3. Maksud dan Tujuan

## 4. Sasaran Peserta

- Jabatan & jenjang / kualifikasi BUJK:
- Jabatan peserta di BUJK (PUB):
- Target jumlah peserta:

## 5. Ruang Lingkup dan Materi

| No | Materi / Modul | Unit Kompetensi / KUK atau Modul PUB | Durasi | Narasumber / Agen |
| --- | --- | --- | --- | --- |
| 1 |  |  |  |  |

## 6. Metode Pelaksanaan

- Bentuk: (tryout / pembelajaran PKB / workshop / sosialisasi / pembelajaran tekstual / interaktif jarak jauh / bimtek / pendampingan intensif)
- Metode: daring / luring / hybrid
- Sifat (PKB): khusus / umum · terverifikasi / tidak terverifikasi

## 7. Narasumber, Instruktur, dan Agen AI

## 8. Jadwal dan Tempat / Platform

| Hari / Tanggal | Waktu | Kegiatan | Keterangan |
| --- | --- | --- | --- |
|  |  |  |  |

## 9. Keluaran dan Indikator Keberhasilan

- Kehadiran ≥ … %
- Kenaikan nilai pre-test → post-test ≥ …
- Kepuasan peserta ≥ … (skala 1–5)
- Produk peserta (mis. executive summary untuk PKB):

## 10. Anggaran

| Komponen | Volume | Satuan | Biaya |
| --- | --- | --- | --- |
|  |  |  |  |

## 11. Rencana Evaluasi dan Pelaporan

- Evaluasi peserta: pre-test, post-test, tugas/produk
- Evaluasi penyelenggaraan: substansi materi, penyampaian instruktur, pelayanan penyelenggara
- Tenggat laporan:

## 12. Persetujuan KAK

| Disusun oleh | Disetujui oleh | Tanggal |
| --- | --- | --- |
|  |  |  |

---

# B. Laporan Kegiatan

## 1. Identitas Kegiatan

- Nama asosiasi penyelenggara:
- Sifat dan bentuk kegiatan:
- Tempat / platform dan tanggal:
- Nomor KAK / referensi:

## 2. Daftar Peserta

| No | Nama | Asosiasi Asal | No. KTA | BUJK Pengutus | Jabatan di BUJK | Jabatan & Jenjang | Status Kehadiran |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 1 |  |  |  |  |  |  |  |

## 3. Materi yang Disampaikan

## 4. Dokumentasi Kegiatan

- **Absensi:** rekap check-in / check-out dan durasi per peserta (lampiran dari Absensi & Log)
- **Time stamps:** log aktivitas mulai/selesai materi, tes, dan simulasi
- **Data statistik:** jumlah terdaftar vs hadir, % kehadiran, % penyelesaian, rata-rata pre/post-test, n-gain, sebaran nilai
- **Rekap per asosiasi dan per BUJK**
- **Foto / tangkapan layar / rekaman sesi**
- **Produk peserta:** executive summary / tugas (PKB)

## 5. Hasil Evaluasi

| Indikator | Target (KAK) | Capaian | Keterangan |
| --- | --- | --- | --- |
| Kehadiran |  |  |  |
| Kenaikan nilai |  |  |  |
| Kepuasan — substansi materi |  |  |  |
| Kepuasan — penyampaian instruktur |  |  |  |
| Kepuasan — pelayanan penyelenggara |  |  |  |

## 6. Rekomendasi dan Rencana Tindak Lanjut

## 7. Lampiran

- Daftar hadir dan log time stamp (CSV/Excel)
- Sertifikat peserta (QR/hash)
- Berkas siap unggah SIJK

## 8. Pengesahan

| Penanggung Jawab Kegiatan | Ketua / Pengurus Asosiasi | Tanggal |
| --- | --- | --- |
|  |  |  |